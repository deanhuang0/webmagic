package us.codecraft.webmagic.samples.pipeline;

/**
 * @author code4crafer@gmail.com
 */
public class ReplacePipeline {
}
