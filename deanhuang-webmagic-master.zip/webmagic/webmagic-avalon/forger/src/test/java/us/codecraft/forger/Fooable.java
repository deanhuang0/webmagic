package us.codecraft.forger;

/**
 * @author code4crafter@gmail.com
 */
public interface Fooable {

    public String foo();
}
