urls "http://my\\.oschina\\.net/flashsword/blog/\\d+"
title = css "div.BlogTitle h1"
content = css "div.BlogContent"

return {"title"=>title,"content"=>content}

