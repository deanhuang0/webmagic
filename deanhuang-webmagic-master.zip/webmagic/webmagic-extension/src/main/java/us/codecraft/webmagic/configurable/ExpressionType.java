package us.codecraft.webmagic.configurable;

/**
 * @author code4crafter@gmail.com
 * @date 14-4-5
 */
public enum ExpressionType {

    XPath, Regex, Css, JsonPath;

}
